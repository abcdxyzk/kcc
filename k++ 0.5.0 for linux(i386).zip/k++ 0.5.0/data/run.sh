#!/bin/sh
as -o ./data/assembly.o ./data/assembly.s 2>data/error.out
ld -dynamic-linker /lib/ld-linux.so.2 -lc -o test ./data/assembly.o 2>>data/error.out
