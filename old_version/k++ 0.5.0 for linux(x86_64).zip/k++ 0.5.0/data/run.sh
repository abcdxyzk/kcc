#!/bin/sh
as -o ./data/assembly.o ./data/assembly.s 2>data/error.out
ld -dynamic-linker /lib64/ld-linux-x86-64.so.2 ./lib/crti.o ./lib/crtbegin.o -L/lib/ -L/usr/lib/ ./data/assembly.o -lm -lc ./lib/crtend.o ./lib/crtn.o -o test 2>>data/error.out
