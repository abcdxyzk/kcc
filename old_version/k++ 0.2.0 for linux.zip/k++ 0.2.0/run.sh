#!/bin/sh
as -o assembly.o assembly.s
ld -dynamic-linker /lib/ld-linux.so.2 -lc -o a.out assembly.o
./a.out
