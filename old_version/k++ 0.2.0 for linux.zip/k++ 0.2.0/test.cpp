
int main()
{
	int i,j,k,l;
	int a[1100][1100];
	char c1,c2,c3,c4;
	double d1,d2,d3;
	
	for(i=0;i<1000;i++)
		for(j=0;j<=i;j++)
		if(i == 0 || j == 0 || i == j)
			a[i][j] = 1;
		else
			a[i][j] = a[i-1][j-1] + a[i-1][j];
			
	for(i=0;i<11;i++)
	{
		for(j=0;j<=i;j++) printf("%d ",a[i][j]);
		printf("\n");
	}
	return 0;
}
