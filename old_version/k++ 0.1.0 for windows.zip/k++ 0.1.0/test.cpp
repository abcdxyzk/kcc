int main()
{
	int i,j,k,l,a[10][10];
	
	for(i=0;i<10;i++)
		for(j=0;j<=i;j++) if(i == 0 || j == 0 || i == j) a[i][j] = 1;
	else
		a[i][j] = a[i-1][j]+ a[i-1][j-1];

	for(i=0;i<10;i++)
	{	
		for(j=0;j<i;j++) printf("%d ",a[i][j]);
		printf("%d\n",a[i][j]);
	}
	while(1);
	return 0;
}
