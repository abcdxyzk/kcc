int main()
{
int i,j,k;
scanf("%d %d\n",&i,&j);
printf("%d\n",i+j);
return 0;
}

