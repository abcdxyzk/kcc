#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<map>
#include<string>
#include<vector>
#include<sstream>
#include<fstream>
#include<iomanip>
#include<iostream>
#include<time.h>

using namespace std;

int main(int argc, char** args)
{
	int i,j,k,l;
	FILE *fp;
	if(argc != 2)
	{
		printf("input file error!\n");
		return 0;
	}
	char ch[3333];
	strcpy(ch, "lexical ");
	strcat(ch, args[1]);
	
	system(ch);
	fp = fopen("error.out","r");
	fgets(ch, 16, fp);
	if(strcmp(ch, "lexcial accept!") != 0)
	{
		printf("%s",ch);
		fgets(ch, 11000, fp);puts(ch);
		return 0;
	}
	
	system("syntax");
	fp = fopen("error.out","r");
	fgets(ch, 15, fp);
	if(strcmp(ch, "syntax accept!") != 0)
	{
		printf("%s",ch);
		fgets(ch, 11000, fp);puts(ch);
		return 0;
	}
	
	system("typecheck");
	fp = fopen("error.out","r");
	fgets(ch, 18, fp);
	if(strcmp(ch, "typecheck accept!") != 0)
	{
		printf("%s",ch);
		fgets(ch, 11000, fp);puts(ch);
		return 0;
	}
	fclose(fp);

	system("semantic");
	system("backend");
	return 0;
}
