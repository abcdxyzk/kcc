#include <stdio.h>

int n,m,a[100000];

int main()
{
    int i,j;
    a[1] = 1; m = 1;
    n = 10;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++) a[j] *= i;
        for(j=1;j<m;j++)
        {
            a[j+1] = a[j+1] + a[j]/10;
            a[j] %= 10;
        }
        while(a[m] >= 10)
        {
            a[m+1] = a[m]/10;
            a[m] %= 10;
            m++;
        }
    }
    for(i=m;i>0;i--) printf("%d",a[i]);
    printf("\n");
    return 0;
}
