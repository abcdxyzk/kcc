/*
#include "stdio.h"
main()
{char a[55];
char b[55];
char c[80],*p;
int i=0,j=0,k=0;
strcpy(a, "acegikm");
strcpy(b, "bdfhjlnpq");

while(a[i]!='\0'&&b[j]!='\0')
{
	if(a[i]!='\0') { c[k]=a[i++];}
	else
	c[k]=b[j++];
	k++;
}
c[k]='\0';
if(a[i]=='\0')
p=b+j;
else
p=a+i;
strcat(c,p);
puts(c);
}

/*
char swap(char *p1, char *p2)
{
char p[20];
strcpy(p,p1);strcpy(p1,p2);strcpy(p2,p);
}
main()
{
char str1[20],str2[20],str3[20];
printf("please input three strings\n");
scanf("%s",str1);
scanf("%s",str2);
scanf("%s",str3);
if(strcmp(str1,str2)>0) swap(str1,str2);
if(strcmp(str1,str3)>0) swap(str1,str3);
if(strcmp(str2,str3)>0) swap(str2,str3);
printf("after being sorted\n");
printf("%s\n%s\n%s\n",str1,str2,str3);
}

/*
move(int array[20], int n, int m)
{
int *p,array_end;
array_end=*(array+n-1);
for(p=array+n-1;p>array;p--)
*p=*(p-1);
*p=array_end;
m--;
if(m>0) move(array,n,m);
}
main()
{
int number[20],n,m,i;
printf("the total numbers is:");
scanf("%d",&n);
printf("back m:");
scanf("%d",&m);
for(i=0;i<n-1;i++)
scanf("%d,",&number[i]);
scanf("%d",&number[n-1]);
move(number,n,m);
for(i=0;i<n-1;i++)
printf("%d,",number[i]);
printf("%d\n",number[n-1]);
}

/*
move(char array[20], int n, int m)
{
char *p,array_end;
array_end=*(array+n-1);
for(p=array+n-1;p>array;p--)
*p=*(p-1);
*p=array_end;
m--;
if(m>0) move(array,n,m);
}
main()
{
char number[20];
int n,m,i;
printf("the total numbers is:");
scanf("%d",&n);
printf("back m:");
scanf("%d",&m);
for(i=0;i<n-1;i++)
scanf("%c,",&number[i]);
scanf("%c",&number[n-1]);
move(number,n,m);
for(i=0;i<n-1;i++)
printf("%d,",number[i]);
printf("%d\n",number[n-1]);
}

/*
move(double array[20], int n, int m)
{
double *p,array_end;
array_end=*(array+n-1);
for(p=array+n-1;p>array;p--)
*p=*(p-1);
*p=array_end;
m--;
if(m>0) move(array,n,m);
}
main()
{
double number[20];
int n,m,i;
printf("the total numbers is:");
scanf("%d",&n);
printf("back m:");
scanf("%d",&m);
for(i=0;i<n-1;i++)
scanf("%lf,",&number[i]);
scanf("%lf",&number[n-1]);
move(number,n,m);
for(i=0;i<n-1;i++)
printf("%.1lf,",number[i]);
printf("%.1lf\n",number[n-1]);
}

/*
int out(int abc)
{
	printf("%d\n",abc);
	return abc;
}

int main()
{
	int i,*p,n=10,a[10][10];
	int d,f[10];
	scanf("%d %d",&n,&a[5][5]);
	printf("%d %d\n",n,a[5][5]);
	d = (int)out(123);
	d = 123;
	printf("%d\n",d);
	f[0] = 1;
	for(i=1;i<10;i++) f[i] = f[i-1]<<1;
	for(i=1;i<10;i++)
		//if(n>=f[i]) 
		printf("%d %d\n",i,f[i]);
	return 0;
}

/*
double ab(double d)
{

}

int main()
{
	char c;
	int i,*p,n=10,a[10][10];
	double d1,d2,f[10];
	f[1] = 1.0; f[2] = 2.0;
	c = 2; i = 2;
	d1 = ab(d1);
	printf("%lf %lf %lf\n",f[1]/c,f[1]/i,f[1]/f[2]);
	return 0;
}

/*
#include "string.h"
#include "stdio.h"
main()
{char str1[20],str2[20],*p1,*p2;
int sum=0;
printf("please input two strings\n");
scanf("%s%s",str1,str2);
p1=str1;p2=str2;
while(*p1!='\0')
{
if(*p1==*p2)
{while(*p1==*p2&&*p2!='\0')
{p1++;
p2++;}
}
else
p1++;
if(*p2=='\0')
sum++;
p2=str2;
}
printf("%d\n",sum);
}  

/*
main()
{ char *p,s[6];int n;
p=s;
gets(p);
n=0;
while(*(p)!='\0')
{n=n*8+*p-'0';
p++;}
printf("%d\n",n);
} 

/*
output(long b,long i)
{ printf("%ld/%ld=809*%ld+%ld\n",b,i,i,b%i);
}
main()
{long int a,b,i;
a=809;
for(i=10;i<100;i++)
{b=i*a+1;
if(b>=1000&&b<=10000&&8*i<100&&9*i>=100)
output(b,i); }
} 

/*
main()
{int i,m,j,k,count;
for(i=4;i<10000;i+=4)
{ count=0;
m=i;
for(k=0;k<5;k++)
{
j=i/4*5+1;
i=j;
if(j%4==0)
count++;
else
break;
}
i=m;
if(count==4)
{printf("%d\n",count);
break;}
}
}

/*
int length(char *p)
{
int n;
n=0;
while(*p!='\0')
{
n++;
p++;
}
return n;
}
main()
{
int len;
char str[20];
printf("please input a string:\n");
scanf("%s",str);
len=length(str);
printf("the string %s has %d characters.\n",str,len);
}

/*
main()
{
int i,n;
char k,m,num[55],*p;
printf("please input the total of numbers:");
scanf("%d",&n);
p=num;
for(i=0;i<n;i++)
*(p+i)=i+1;
i=0;
k=0;
m=0;
while(m<n-1)
{
if(*(p+i)!=0) k++;
if(k==3)
{*(p+i)=0;
k=0;
m++;
}
i++;
if(i==n) i=0;
}
while(*p==0) p++;
printf("%d is left\n",*p);
} 

/*
void input(int numbe[10], int n, int number[10])
{
	int i;
	printf("n = %d\n",n);
	for(i=0;i<n;i++)
		scanf("%d,",&number[i]);
	scanf("%d",&number[9]);
}

max_min(int array[10])
{
int i;
int *max,*min,k,l;
int *p,*arr_end;

arr_end=array+10;
max=min=array;
for(p=array+1;p<arr_end;p++)
if(*p>*max) max=p;
else if(*p<*min) min=p;

k=*max;
l=*min;
//printf("max = %d  min = %d\n",k,l);
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
p=&array[9]; 
*max = *p; *p = k;
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
p=&array[0]; 
*min = array[0]; *p = l;
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
return;
}

output(int *array)
{int *p;
for(p=array;p<array+9;p++)
printf("%d,",*p);
printf("%d\n",*p);
}

main()
{
int number[10];
input(number, 9, number);
max_min(number);
output(number);
}

/*
void input(char numbe[10], int n, char number[10])
{
	int i;
	printf("n = %d\n",n);
	for(i=0;i<n;i++)
		scanf("%c,",&number[i]);
	scanf("%c",&number[9]);
}

max_min(char array[10])
{
int i;
char *max,*min,k,l;
char *p,*arr_end;

arr_end=array+10;
max=min=array;
for(p=array+1;p<arr_end;p++)
if(*p>*max) max=p;
else if(*p<*min) min=p;

k=*max;
l=*min;
//printf("max = %d  min = %d\n",k,l);
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
p=&array[9]; 
*max = *p; *p = k;
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
p=&array[0]; 
*min = array[0]; *p = l;
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
return;
}

output(char *array)
{char *p;
for(p=array;p<array+9;p++)
printf("%c,",*p);
printf("%c\n",*p);
} 

main()
{
char number[10];
input(number, 9, number);
max_min(number);
output(number);
}

/*
void input(double numbe[10], int n, double number[10])
{
	int i;
	printf("n = %d\n",n);
	for(i=0;i<n;i++)
		scanf("%lf,",&number[i]);
	scanf("%lf",&number[9]);
}

max_min(double array[10])
{
int i;
double *max,*min,k,l;
double *p,*arr_end;

arr_end=array+10;
max=min=array;
for(p=array+1;p<arr_end;p++)
if(*p>*max) max=p;
else if(*p<*min) min=p;

k=*max;
l=*min;
//printf("max = %d  min = %d\n",k,l);
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
p=&array[9]; 
*max = *p; *p = k;
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
p=&array[0]; 
*min = array[0]; *p = l;
//for(i=0;i<10;i++) printf("%d ",array[i]); printf("\n");
return;
}

output(double *array)
{double *p;
for(p=array+9;p>array;p--)
printf("%.0lf,",*p);
printf("%.0lf\n",*p);
} 

main()
{
double number[10];
double *p;
input(number, 9, number);
max_min(number);
output(number);
for(p=number+9;p>number;p--)
printf("%.0lf,",*p);
printf("%.0lf\n",*p);
}

/*
int main()
{
	int i,j,a[10][10];
	for(i=0;i<10;i++)
		for(j=0;j<=i;j++) if(i == 0 || j == 0 || i == j) a[i][j] = 1;
		else
			a[i][j] = a[i-1][j] + a[i-1][j-1];
	
	for(i=0;i<10;i++)
	{
		for(j=0;j<=i;j++) printf("%d ",a[i][j]);
		printf("\n");
	}
			
	return 0;
}

/*
swap(int *p1, int *p2)
{int p;
p=*p1;*p1=*p2;*p2=p;
} 
main()
{
int n1,n2,n3;
int *pointer1,*pointer2,*pointer3;
printf("please input 3 number:n1,n2,n3:");
scanf("%d,%d,%d",&n1,&n2,&n3);
pointer1=&n1;
pointer2=&n2;
pointer3=&n3;
if(n1>n2) swap(pointer1,pointer2);
if(n1>n3) swap(pointer1,pointer3);
if(n2>n3) swap(pointer2,pointer3);
printf("the sorted numbers are:%d,%d,%d\n",n1,n2,n3);
}

/*
#include <stdio.h>
int n,ans=0,a[33],b[33],c[33];

void dfs(int kk)
{
     int i;
     if(kk == n)
     {
          ans++;
          return;
     }

     for(i=0;i<n;i++)
     if(a[i] == 0 && b[kk+i] == 0 && c[kk-i+n] == 0)
     {
          a[i] = 1;
          b[kk+i] = 1;
          c[kk-i+n] = 1;

          dfs(kk+1);

          a[i] = 0;
          b[kk+i] = 0;
          c[kk-i+n] = 0;
     }
}

int cloc()
{
	return 123;
}

int main()
{
     int i,j,k,l;
     double d;
     n = 13;
    for(i=0;i<n+n;i++) {
          a[i] = 0;
          b[i] = 0;
          c[i] = 0;
     }
     ans = 0;
    dfs(0);
    printf("%d\n",ans);
    d = clock();
    printf("%lf\n",d/1000.0);
    return 0;
}

/*
#include <stdio.h>

int n,m,a[100000];

int main()
{
    int i,j;
    a[1] = 1; m = 1;
    n = 10;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++) a[j] *= i;
        for(j=1;j<m;j++)
        {
            a[j+1] = a[j+1] + a[j]/10;
            a[j] %= 10;
        }
        while(a[m] >= 10)
        {
            a[m+1] = a[m]/10;
            a[m] %= 10;
            m++;
        }
    }
    for(i=m;i>0;i--) printf("%d",a[i]);
    printf("\n");
    return 0;
}

/*
char add(int p, int o)
{
//	return p;
	if(p < o) return o;
	return p;
}

int main()
{
	int i,j,*p,*q[11],a[10];
	double d;
	i = 12; j = 23;
	i = add(12, 23);
	printf("%d %d\n",add(12, 23),add(33, 23));
	return 0;
}

/*
void add(int *p)
{
	*p = 57;
	p=p-p-p; p = 3-p;
	*p = 12;
	p-=6;
	*p = 123;
}

void out(double kk)
{
	printf("%lf\n",kk);
}

int main()
{
	int i,j;
	int *p,*q[11][11],a[100000];
	q[5][5] = a + 5;
	add(&a[5]);
	out(*q[5][5]);
	printf("%d %d\n",a[8],*(q[5][5]-3));
	for(i=0;i<1000;i++)
	{
		p = a;
		j = 0;
		do {
			//a[j] = j;
			*p = j;
			p++;j++;
		} while(j < 100000);
	}
	printf("%lf\n",clock()/1000.0);
	return 0;
}

/*
char out(int *kk, int ll)
{
	char c='a';
	*kk = 56;
	printf("%d %d\n",*kk,ll);
	
	return ll;
}

int main()
{
	int i,j;
	char k;
	int *p;
	p = &j;
	i = 123;
	k = out(p, i);
	printf("%d %d\n",*p,k);
	return 0;
}

/*
int main()
{
	char *pc,*pcc,c,cc;
	int *pi,*pii,i,ii;
	double *pd,*pdd,d,dd;
	pc = &c;
	pi = &i;
	pd = &d;
	pcc = &cc;
	pii = &ii;
	pdd = &dd;
	c = 1;
	i = 2;
	d = 3;
	cc = 11;
	ii = 22;
	dd = 33;
	*pc = *pcc;
	printf("%d\n",*pc);
	*pc = *pii;
	printf("%d\n",*pc);
	
	*pi = *pcc;
	printf("%d\n",*pi);
	*pi = *pii;
	printf("%d\n",*pi);
	
	*pd = *pcc;
	printf("%lf\n",*pd);
	*pd = *pii;
	printf("%lf\n",*pd);
	*pd = *pdd;
	printf("%lf\n",*pd);
	
	c = *pcc;
	printf("%d\n",c);
	c = *pii;
	printf("%d\n",c);
	
	i = *pcc;
	printf("%d\n",i);
	i = *pii;
	printf("%d\n",i);
	
	d = *pcc;
	printf("%lf\n",d);
	d = *pii;
	printf("%lf\n",d);
	d = *pdd;
	printf("%lf\n",d);
	return 0;
}

*/
/*
char abc(char cc)
{
	return cc+1;
}

int abi(int ii)
{
	return ii+1;
}

double abd(double dd)
{
	return dd+1;
}

int main()
{
	char c,cc;
	int i,ii;
	double d,dd;
	cc = 'a';
	ii = 123;
	dd = 123.456;
	
	c = abc(cc);
	printf("%d\n",c);
	c = abc(ii);
	printf("%d\n",c);
	
	i = abi(cc);
	printf("%d\n",i);
	i = abi(ii);
	printf("%d\n",i);
	
	d = abd(cc);
	printf("%lf\n",d);
	d = abd(ii);
	printf("%lf\n",d);
	d = abd(dd);
	printf("%lf\n",d);
	return 0;
}
*/

int main()
{
	int i;
	double d;
	i = 123;
	d = 100.123;
	d = sqrt(d);//sin(3.1415926/2.0);
	printf("%lf\n",d);
	return 0;
}
