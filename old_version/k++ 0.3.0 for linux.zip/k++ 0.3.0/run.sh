#!/bin/sh
as -o ./data/assembly.o ./data/assembly.s
ld -dynamic-linker /lib/ld-linux.so.2 -lc -o a.out ./data/assembly.o
./a.out
